public class main {
    public static void main(String[] args) {
        // Creating a Person object with initial values
        Person person1 = new Person("Alice", 30);
        
        // Getting and printing initial values
        System.out.println("Name: " + person1.getName());
        System.out.println("Age: " + person1.getAge());
        
        // Setting new values
      ;
    }
}
