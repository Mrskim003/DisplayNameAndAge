import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class SimpleGui {
        public static void main(String[] args) {
        // Create JFrame
        JFrame frame = new JFrame("Simple GUI");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Create JPanel
        JPanel panel = new JPanel();
        
        // Create JTextField for name input
        JTextField nameField = new JTextField(20);
        
        // Create JTextField for age input
        JTextField ageField = new JTextField(5);
        
        // Create JButton for submit
        JButton submitButton = new JButton("Submit");
        
        // Create JLabel for displaying result
        JLabel resultLabel = new JLabel();
        
        // Add components to the panel
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Age:"));
        panel.add(ageField);
        panel.add(submitButton);
        panel.add(resultLabel);
        
        // Add ActionListener to the submit button
        submitButton.addActionListener(e -> {
            String name = nameField.getText();
            String age = ageField.getText();
            resultLabel.setText("Name: " + name + ", Age: " + age);
        });
        
        // Add panel to the frame and make it visible
        frame.add(panel);
        frame.setVisible(true);
    }

}
